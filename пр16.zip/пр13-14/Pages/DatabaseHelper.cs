﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using пр13_14;
using пр13_14.Pages;

namespace пр13_14
{
    public static class DatabaseHelper
    {
        private static EventOrganizerDBEntities1 GetContext()
        {
            return new EventOrganizerDBEntities1();
        }

        public static bool TestConnection()
        {
            try
            {
                using (var context = GetContext())
                {
                    var count = context.Users.Count();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        public static int? ValidateUser(string login, string password)
        {
            try
            {
                using (var context = GetContext())
                {
                    var user = context.Users.FirstOrDefault(u => u.Login == login && u.Password == password);

                    if (user != null)
                    {
                        return user.RoleID;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка БД: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return null;
        }

        public static object GetEventsForManager()
        {
            try
            {
                using (var context = GetContext())
                {
                    var events = context.Events
                        .OrderByDescending(e => e.EventDate)
                        .Select(e => new
                        {
                            EventID = e.EventID,
                            Title = e.EventName,       
                            EventDate = e.EventDate,
                            TypeName = e.EventType,    
                            VenueName = e.Location,    
                            Status = e.Status
                        })
                        .ToList();

                    return events;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки мероприятий: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
        }

        public static bool RegisterUser(string fullName, string email, string login, string password)
        {
            try
            {
                using (var context = GetContext())
                {
                    if (context.Users.Any(u => u.Login == login))
                    {
                        MessageBox.Show("Пользователь с таким логином уже существует!");
                        return false;
                    }

                    string[] nameParts = fullName.Split(new char[] { ' ' }, 2);
                    string firstName = nameParts[0];
                    string lastName = nameParts.Length > 1 ? nameParts[1] : "";

                    var newUser = new Users
                    {
                        Login = login,
                        Password = password,
                        FirstName = firstName,
                        LastName = lastName,
                        Email = email,
                        RoleID = 3, 
                        CreatedAt = DateTime.Now
                    };

                    context.Users.Add(newUser);
                    context.SaveChanges();

                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка регистрации: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }
        public static List<EventCardData> GetEventsWithImages()
        {
            try
            {
                using (var context = GetContext())
                {
                    var events = context.Events
                        .OrderByDescending(e => e.EventDate)
                        .Select(e => new EventCardData
                        {
                            EventID = e.EventID,
                            EventName = e.EventName,
                            EventType = e.EventType,
                            EventDate = e.EventDate,
                            Location = e.Location,
                            TotalBudget = e.TotalBudget,
                            Status = e.Status,
                            Image = e.Image
                        })
                        .ToList();

                    return events;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return new List<EventCardData>();
            }
        }
        public static bool AddEvent(string title, DateTime date, decimal budget, int typeId, int locationId, int organizerId)
        {
            try
            {
                using (var context = GetContext())
                {
                    string eventTypeStr = "General";
                    if (typeId == 1) eventTypeStr = "Corporate";
                    else if (typeId == 2) eventTypeStr = "Wedding";

                    string locationStr = "Main Hall";
                    if (locationId == 1) locationStr = "Hall A";
                    else if (locationId == 2) locationStr = "Garden";

                    var newEvent = new Events
                    {
                        EventName = title,
                        EventType = eventTypeStr,
                        EventDate = date,
                        TotalBudget = budget,
                        Status = "Planning",
                        ManagerID = organizerId,
                        Location = locationStr,
                        Description = "Created via App"
                    };

                    context.Events.Add(newEvent);
                    context.SaveChanges();

                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка создания: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }
    }
}