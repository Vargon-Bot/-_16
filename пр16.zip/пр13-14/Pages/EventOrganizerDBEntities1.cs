﻿using System.Data.Entity;

namespace пр13_14
{
    public class EventOrganizerDBEntities1 : DbContext
    {
        public EventOrganizerDBEntities1() : base("name=EventOrganizerDBEntities1")
        {
            Database.SetInitializer(new CreateDatabaseIfNotExists<EventOrganizerDBEntities1>());
        }

        public DbSet<Users> Users { get; set; }
        public DbSet<Events> Events { get; set; }
    }
}